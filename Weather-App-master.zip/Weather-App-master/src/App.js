import React from "react";
import SearchWeather from "./components/SearchWeather";

function App() {
  return (
    <div className="App">
      <SearchWeather />
    </div>
  );
}

export default App;
